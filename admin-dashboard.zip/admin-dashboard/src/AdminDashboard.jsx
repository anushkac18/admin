import React, { useState } from 'react';

export default function AdminDashboard() {
  const [query, setQuery] = useState('');
  const [buses, setBuses] = useState([
    { id: 1, number: '21C', reg: 'PB 07-GG2541', route: 'AMRITSAR TO CHANDIGARH', device: null, available: false },
    { id: 2, number: '3A', reg: 'PB 65-AA1234', route: 'Chandigarh to Amritsar', device: 'AA:BB:CC:DD:EE:01', available: true },
    { id: 3, number: '12B', reg: 'PB 02-BB5678', route: 'Ludhiana to Jalandhar', device: 'BB:CC:DD:EE:FF:02', available: false },
    { id: 4, number: '6A', reg: 'PB 03-CC9012', route: 'Mohali to Bathinda', device: 'CC:DD:EE:FF:AA:03', available: true },
    { id: 5, number: '8C', reg: 'PB 04-DD3456', route: 'Patiala to Shimla', device: 'DD:EE:FF:AA:BB:04', available: true },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(null);
  const [notifications, setNotifications] = useState([]);

  function handleDelete(id) {
    if (!confirm('Delete this bus?')) return;
    setBuses(buses.filter(b => b.id !== id));
  }

  function handleAdd(newBus) {
    setBuses([...buses, { ...newBus, id: Date.now() }]);
    setShowAddModal(false);
  }

  function handleEdit(updatedBus) {
    setBuses(buses.map(b => (b.id === updatedBus.id ? updatedBus : b)));
    setShowEditModal(null);
  }

  function handleLogout() {
    alert('Logging out... (redirect to login)');
  }

  function handleNotifications() {
    setNotifications(["Bus 3A reached Amritsar", "Bus 12B delayed"]); // demo
    alert('Notifications: ' + notifications.join(', '));
  }

  const filtered = buses.filter(b => {
    const q = query.toLowerCase();
    return (
      b.number.toLowerCase().includes(q) ||
      b.reg.toLowerCase().includes(q) ||
      b.route.toLowerCase().includes(q)
    );
  });

  return (
    <div className="min-h-screen bg-gray-50 p-8 font-sans text-gray-700">
      {/* Header */}
      <header className="flex items-center justify-between mb-6">
        <div>
          <a className="inline-flex items-center text-blue-700 hover:underline mr-4" href="#">&larr; Back</a>
          <h1 className="text-2xl font-bold text-blue-700">Admin Dashboard</h1>
          <p className="text-sm text-gray-500">Welcome, Punjab Transport Admin</p>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={handleNotifications} className="px-4 py-2 border rounded bg-white">Notifications</button>
          <button onClick={handleLogout} className="px-4 py-2 rounded bg-red-500 text-white">Logout</button>
        </div>
      </header>

      {/* Controls */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <nav className="flex items-center gap-6 text-gray-600">
          <button className="py-2">View Buses</button>
          <button onClick={() => setShowAddModal(true)} className="py-2 bg-blue-50 text-blue-600 rounded px-3">+ Add Bus</button>
          <button className="py-2">Add Driver</button>
          <button className="py-2">View Drivers</button>
          <button className="py-2">Analytics</button>
          <div className="ml-auto flex items-center gap-3">
            <div className="relative">
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search by bus number or route"
                className="pl-10 pr-4 py-2 rounded-full border w-80 focus:outline-none"
              />
              <svg className="w-5 h-5 absolute left-3 top-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35" />
                <circle cx="11" cy="11" r="6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <button onClick={() => setShowAddModal(true)} className="bg-blue-600 text-white px-4 py-2 rounded">New Bus</button>
          </div>
        </nav>
      </div>

      {/* Table */}
      <section className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">All Buses</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left table-auto">
            <thead className="text-gray-500 text-sm border-b">
              <tr>
                <th className="py-4 px-4 w-24">Bus Number</th>
                <th className="py-4 px-4">Registration</th>
                <th className="py-4 px-4">Route</th>
                <th className="py-4 px-4">Device</th>
                <th className="py-4 px-4">Availability</th>
                <th className="py-4 px-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(bus => (
                <tr key={bus.id} className="border-b last:border-b-0">
                  <td className="py-5 px-4 font-medium">{bus.number}</td>
                  <td className="py-5 px-4 text-sm text-gray-500">{bus.reg}</td>
                  <td className="py-5 px-4 text-sm">{bus.route}</td>
                  <td className="py-5 px-4 text-sm">
                    {bus.device ? (
                      <span className="inline-flex items-center gap-2">
                        <svg className="w-4 h-4 text-green-500 animate-spin-slow" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M12 4v4m0 8v4m8-8h-4M4 12H8"/></svg>
                        <span className="text-teal-600">{bus.device}</span>
                      </span>
                    ) : (
                      <span className="text-gray-400">No Device</span>
                    )}
                  </td>
                  <td className="py-5 px-4">
                    {bus.available ? (
                      <span className="inline-block px-3 py-1 rounded-full bg-green-50 text-green-700 text-sm">Available</span>
                    ) : (
                      <span className="inline-block px-3 py-1 rounded-full bg-red-50 text-red-600 text-sm">Unavailable</span>
                    )}
                  </td>
                  <td className="py-5 px-4">
                    <div className="flex gap-3">
                      <button onClick={() => setShowEditModal(bus)} className="px-3 py-1 rounded bg-blue-600 text-white">Edit</button>
                      <button onClick={() => handleDelete(bus.id)} className="px-3 py-1 rounded bg-pink-500 text-white">Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Add Modal */}
      {showAddModal && (
        <Modal title="Add New Bus" onClose={() => setShowAddModal(false)}>
          <BusForm onSubmit={handleAdd} />
        </Modal>
      )}

      {/* Edit Modal */}
      {showEditModal && (
        <Modal title="Edit Bus" onClose={() => setShowEditModal(null)}>
          <BusForm bus={showEditModal} onSubmit={handleEdit} />
        </Modal>
      )}

      <footer className="mt-6 text-sm text-gray-400">Trackila Admin Dashboard — React (tailwind) — sample frontend</footer>
    </div>
  );
}

function Modal({ title, children, onClose }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-black">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function BusForm({ bus = {}, onSubmit }) {
  const [form, setForm] = useState({
    id: bus.id || null,
    number: bus.number || '',
    reg: bus.reg || '',
    route: bus.route || '',
    device: bus.device || '',
    available: bus.available || false,
  });

  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    setForm({ ...form, [name]: type === 'checkbox' ? checked : value });
  }

  function handleSubmit(e) {
    e.preventDefault();
    onSubmit(form);
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <input name="number" value={form.number} onChange={handleChange} placeholder="Bus Number" className="border p-2 rounded" required />
      <input name="reg" value={form.reg} onChange={handleChange} placeholder="Registration" className="border p-2 rounded" required />
      <input name="route" value={form.route} onChange={handleChange} placeholder="Route" className="border p-2 rounded" required />
      <input name="device" value={form.device} onChange={handleChange} placeholder="Device ID" className="border p-2 rounded" />
      <label className="flex items-center gap-2">
        <input type="checkbox" name="available" checked={form.available} onChange={handleChange} /> Available
      </label>
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
    </form>
  );
}
